JetCreator demonstration content

The "JetCreator_content" folder contains JetCreator sample files.

1. Open a command prompt and go to the directory where the JetCreator tool is located.

2. Launch JET Creator by typing "Python JetCreator.py" (be sure Python and WXWidgets are installed on your system)

3. Select the IMPORT command and import one of the JetCreator_demo_*.zip files.

4. After importing the first time, you can use the OPEN command to open the .jtc file in the folder you selected as the target for import.
